#!/bin/bash
set -ex

# $2 is the install location, ($HOME by default)
if [ xxx$PREFIX == 'xxx' ]; then
    PREFIX=$(cd "$2/__NAME_LOWER__"; pwd)
fi


echo '## Hello from Post_install script ' > $HOME/logCitationProfiler.txt
#printenv >> $HOME/logCitationProfiler.txt

echo '## Citation Profiler is installed at' >> $HOME/logCitationProfiler.txt
echo "$PREFIX" >> $HOME/logCitationProfiler.txt
echo '## To uninstall' >> $HOME/logCitationProfiler.txt
echo 'move citation-profiler directory from the above path to bin.' >> $HOME/logCitationProfiler.txt
echo 'Delete app icon from the Applications folder' >> $HOME/logCitationProfiler.txt

cd $PREFIX

tar -xvf docs.zip
tar -xvf your-results.zip
tar -xvf your-data.zip
tar -xvf settings.zip
rm -rf docs.zip your-results.zip your-data.zip settings.zip

chmod +x Citation-Profiler.sh
chmod +x make_app.sh
./make_app.sh Citation-Profiler.sh Citation-Profiler

osascript -e 'tell application "Finder"' -e 'make new alias to file (posix file "'"$PREFIX"'/Citation-Profiler-main.command") at (posix file "'"$PREFIX/Citation-Profiler.app/Contents/MacOS/"'")' -e 'end tell'

mkdir -p Citation-Profiler.app/Contents/Resources
cp Tk.icns Citation-Profiler.app/Contents/Resources/Icon.icns
mv Info.plist Citation-Profiler.app/Contents/
cp -r Citation-Profiler.app /Applications/
