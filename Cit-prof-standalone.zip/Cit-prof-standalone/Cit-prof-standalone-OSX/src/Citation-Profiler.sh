#!/bin/bash

BASEDIR=$(dirname $0)
cd $BASEDIR
#cd ../../../
open Citation-Profiler-main.command
wait
