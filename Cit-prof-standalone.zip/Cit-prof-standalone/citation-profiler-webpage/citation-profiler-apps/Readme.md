Add the apps here to be downloaded from webpage.
