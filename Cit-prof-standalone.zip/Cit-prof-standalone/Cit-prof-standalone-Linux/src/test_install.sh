#!/bin/bash
set -ex

# $2 is the install location, ($HOME by default)
if [ xxx$PREFIX == 'xxx' ]; then
    PREFIX=$(cd "$2/__NAME_LOWER__"; pwd)
fi


echo '## Hello from Post_install script ' > $HOME/logCitationProfiler.txt
#printenv >> $HOME/logCitationProfiler.txt

echo '## Citation Profiler is installed at' >> $HOME/logCitationProfiler.txt
echo "$PREFIX" >> $HOME/logCitationProfiler.txt
#echo '## To uninstall' >> $HOME/logCitationProfiler.txt
#echo 'move citation-profiler directory from the above path to bin.' >> $HOME/logCitationProfiler.txt
#echo 'Delete app icon from the Applications folder' >> $HOME/logCitationProfiler.txt

cd $PREFIX

tar -xvf docs.tar.gz
tar -xvf your-results.tar.gz
tar -xvf your-data.tar.gz
tar -xvf settings.tar.gz
rm -rf docs.tar.gz your-results.tar.gz your-data.tar.gz settings.tar.gz

chmod +x Citation-Profiler.sh
chmod +x Citation-Profiler-uninstall.sh

sed -i "s|path|$PREFIX|g" cit-prof.desktop
sed -i "s|path|$PREFIX|g" cit-prof-uninstall.desktop
chmod +x cit-prof.desktop
chmod +x cit-prof-uninstall.desktop
mkdir -p ~/.local/share/applications/citation-profiler
cp cit-prof.desktop ~/.local/share/applications/citation-profiler/
cp cit-prof-uninstall.desktop ~/.local/share/applications/citation-profiler/
cd $PREFIX

