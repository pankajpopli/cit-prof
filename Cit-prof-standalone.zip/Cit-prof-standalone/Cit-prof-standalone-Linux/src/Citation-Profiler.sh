#!/bin/bash

#BASEDIR=$(dirname $0)
#cd $BASEDIR

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
cd $SCRIPT_DIR

timeStamp=$(date +"%D %T")

echo "" >> nohup.out
echo '------------------' >> nohup.out
echo "$timeStamp" >> nohup.out
echo '------------------' >> nohup.out

zenity --info --text="The Citation Profiler app will open in a web-browser shortly. If it does not open, make sure you have Google-Chrome browser installed and set as default or try pressing enter in terminal or close the app and reopen again." --title="Citation Profiler"
echo '--------------------------------------------------'
echo '           Citation Profiler started              '
echo '--------------------------------------------------'
echo '    [1]: Waiting for browser to respond...        ' 
echo '    [2]: Press enter if application is taking time to load.'

nohup bin/voila Calculate-citation-profile.ipynb --VoilaConfiguration.file_whitelist your-data/ExampleData.dat &

( tail -f -n0 nohup.out & ) | grep -q "Kernel shutdown"
#rm -rf nohup.out
PID=$!
echo $PID
kill $PID
if [ $? -eq 0 ]; then
   echo "-- from shell script: Process killed succesfully $PID" >> nohup.out
else
      echo "-- from shell script: Could not kill the process $PID" >> nohup.out
fi
