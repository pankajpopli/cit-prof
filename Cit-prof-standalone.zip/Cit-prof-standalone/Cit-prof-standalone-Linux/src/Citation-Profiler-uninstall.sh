#!/bin/bash


#BASEDIR=$(dirname $0)
#cd $BASEDIR

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
cd $SCRIPT_DIR

PREFIX=$SCRIPT_DIR

echo '--------------------------------------------------'
echo '         Uninstalling Citation Profiler           '
echo '--------------------------------------------------'

echo "-->[1] Removing installed packages..."
rm -rf $PREFIX
retval=$?
if [ $retval -ne 0 ]; then
    echo "Could not delete the package folder."
    echo "Following error was generated,"
    echo "$retval"
    echo ""
    echo ""
    echo " To delete mannualy, trash the entire folder citation-profiler from the following path,"
    echo "$PREFIX"
    echo ""
    echo " also delete the icon files from ~/.local/share/applications/citation-profiler"
fi
wait
echo "main package successfully removed from $PREFIX"

echo "-->[2] Removing dash menu icons"
rm -rf ~/.local/share/applications/citation-profiler
retval=$?
if [ $retval -ne 0 ]; then
    echo "Could not delete the dash menu icons"
    echo "Following error was generated,"
    echo "$retval"
    echo ""
    echo ""
    echo " To delete mannualy, trash the entire folder from the following path,"
    echo ""
    echo " ~/.local/share/applications/citation-profiler"
fi

wait

echo '--------------------------------------------------'
echo "          Uninstall successful"
echo '--------------------------------------------------'
read -p "Press any key to exit this terminal window."

