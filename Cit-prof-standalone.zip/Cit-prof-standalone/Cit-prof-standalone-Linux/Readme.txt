To construct the installable package for Linux
-----------------------------------------------

1) Install Anaconda
2) Install conda constructor package from conda-forge along with dev tools
3) use command 'constructor src/' to compile installabe script
